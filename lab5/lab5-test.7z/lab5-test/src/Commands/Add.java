package Commands;

import Models.Route;

public class Add {
    public static void AddCommand (){
        Route route= new Route();
    }
}
