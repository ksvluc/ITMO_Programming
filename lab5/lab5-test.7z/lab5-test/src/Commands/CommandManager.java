package Commands;

import static Commands.Help.HelpCommand;

public class CommandManager {
    public void SearchCommand(String userLine){
        String[] wordsInline = userLine.split(" ");
        String command = wordsInline[0];
        if (command.equals("help")){
            HelpCommand();
        }
        if (command.equals("exit")){
            System.exit(0);
        }
        if (command.equals("add")){

        }

    }
}
