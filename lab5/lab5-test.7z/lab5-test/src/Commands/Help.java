package Commands;

public class Help {
    public static void HelpCommand(){
        System.out.println("help - помощь");
        System.out.println("exit - выйти");

    }
}
