package Data;

import Models.Route;

import java.io.*;
import java.util.LinkedList;

public class DataProvider {
    public void Save(LinkedList<Route> routes, String fileName){

        try{
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName));
            oos.writeObject(routes);
        }
        catch(Exception e){
            System.out.println("Ошибка!");
        }
    }

    public LinkedList<Route> Load(String fileName){
        System.out.println(1.1);
        try{
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName));
            return (LinkedList<Route>) ois.readObject();
        }
        catch(Exception e){
            System.out.println("Файл не найден!");
            return null;
        }
    }
}
