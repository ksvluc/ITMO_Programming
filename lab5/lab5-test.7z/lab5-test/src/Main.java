import Data.DataProvider;
import Models.Filler;
import Models.Route;

import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
    Filler filler = new Filler();
    DataProvider dataProvider = new DataProvider();
    Route rt1 = new Route();
    Route rt2 = new Route();

    LinkedList<Route> routes = new LinkedList<Route>();

    filler.Fill(rt1);
    filler.Fill(rt2);
    routes.add(rt1);
    routes.add(rt2);

    dataProvider.Save(routes, "data.csv");
    LinkedList<Route> routes1 = new LinkedList<Route>();
    System.out.println("Сохранили\n------------");
    System.out.println(routes1);
    System.out.println("------------");

    routes1= dataProvider.Load("data.csv");
    System.out.println(routes1);
    }
}