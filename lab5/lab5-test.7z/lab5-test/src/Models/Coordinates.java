package Models;

public class Coordinates {
}
