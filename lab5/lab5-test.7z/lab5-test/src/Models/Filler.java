package Models;

import java.util.Scanner;

public class Filler {
    public void Fill(Route route) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Введите имя: ");
        route.SetName(sc.nextLine());

        while (true){
            try{

                System.out.print("Введите возраст: ");
                int age = Integer.parseInt(sc.nextLine());
                if (age < 18){
                    System.out.println("Только совершеннолетние!");
                }
                else{
                    route.SetAge(age);
                    break;
                }


            }
            catch(NumberFormatException e){
                System.out.println("Вводить только int!");
            }
        }

    }
}
