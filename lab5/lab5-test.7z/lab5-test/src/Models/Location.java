package Models;

public class Location {
}
