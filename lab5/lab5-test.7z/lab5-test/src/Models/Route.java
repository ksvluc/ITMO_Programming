package Models;

import java.io.Serializable;

public class Route implements Serializable {
    private long id; //Значение поля должно быть больше 0, Значение этого поля должно быть уникальным, Значение этого поля должно генерироваться автоматически
    private String name; //Поле не может быть null, Строка не может быть пустой
    private int age; //Значение поля должно быть больше 0, Значение этого поля должно быть уникальным, Значение этого поля должно генерироваться автоматически
    private Coordinates coordinates; //Поле не может быть null
    private java.time.LocalDateTime creationDate; //Поле не может быть null, Значение этого поля должно генерироваться автоматически
    private Location from; //Поле может быть null
    private Location to; //Поле может быть null
    private int distance; //Значение поля должно быть больше 1
    public void SetAge(int age) {
        this.age = age;
    }

    public void SetName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return("Name: " + name + " Age: " + String.valueOf(age));
    }
}